/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   [40_화면/12_종단.js] 상·하류 종단 화면
   하는 일 : 하천별 상류→하류 그래프, 월 켜기/끄기, 구간별 변화표
   주요 이름: renderProf, profileRoutes
   이럴 때 고침: 종단 그래프·구간 변화 기준(30%)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
registerView({ id:"prof", label:"상·하류 종단", kpi:true, item:true, render:()=>renderProf(),
  bind(){ $("pfCopy").onclick=()=>copyText(tsvText(cache.pfTsv||[])); }});
/* ═════════ 상·하류 종단 ═════════ */
function renderProf(){
  const it = itemOf(S.item), ms = months();
  const seg = $("pfRivers");
  seg.innerHTML = RIVERS().map(r=>`<button data-r="${esc(r)}" aria-pressed="${r===S.profRiver}">${esc(r)} ${ST.filter(s=>s.river===r).length}</button>`).join("");
  seg.querySelectorAll("button").forEach(b=>b.onclick=()=>{ S.profRiver=b.dataset.r; S.profBranch=""; refresh(); });
  const groups = profileBranches(S.profRiver);
  const branch = groups.find(g=>g.name===S.profBranch) || groups[0];
  const choice = $("pfBranch");
  $("pfBranchLabel").hidden = groups.length<=1;
  choice.innerHTML = groups.map(g=>`<option value="${esc(g.name)}">${esc(g.name)}</option>`).join("");
  choice.value = branch.name;
  choice.onchange = e=>{ S.profBranch=e.target.value; refresh(); };
  const path = [];
  for(let g=branch; g && !path.includes(g.name); g=groups.find(other=>other.name===g.next)) path.push(g.name);
  const chain = profChain(S.profRiver);
  $("pfTitle").textContent = `${S.profRiver} ${it.name} 상류 → 하류`;
  $("pfSub").textContent = `${chain.length}개 지점 · ${profCustom(S.profRiver)?path.join(" → "):"지점코드 순서"} · 단위 ${it.unit} · 점 색·크기 = 농도(옅은 파랑 낮음 → 빨강 높음)`;
  const routes=profileRoutes(groups,chain);
  const combined=routes.length>1 && S.profCompare!==false;
  const plotted=combined ? routes : [{name:branch.name,stations:chain}];
  const stations=profileColumns(plotted), cats=stations.map(st=>st.name);
  const indices=new Map(cats.map((name,index)=>[name,index]));
  const records=Object.fromEntries(stations.map(st=>{
    const values=series(st.name,S.item);
    return [st.name,{values,stats:stats(values)}];
  }));
  const ink2=css("--ink-2"), ink3=css("--ink-3"), panel=css("--panel");
  const log=S.opt.scale==="log";
  const shown=value=>Number.isFinite(value) && (!log || value>0);
  let last=ms.length-1;
  while(last>=0 && !stations.some(st=>shown(records[st.name].values[last]))) last--;
  const focus=ms.includes(S.profMonth)?ms.indexOf(S.profMonth):last;
  const values=stations.flatMap(st=>records[st.name].values.filter(shown));
  const range=concRange(values);
  const cpt=v=>concT(v,range.lo,range.hi);
  const monthly=plotted.flatMap(route=>ms.flatMap((_,i)=>i!==focus && S.profBackground!==false ?
    [route.stations.map(st=>[indices.get(st.name),records[st.name].values[i]])] : []));
  const background=[];
  for(const points of monthly){
    for(let j=1;j<points.length;j++){
      const [a,b]=[points[j-1],points[j]];
      if(shown(a[1]) && shown(b[1])) background.push([...a,...b]);
    }
  }
  const ser=[];
  if(background.length) ser.push({name:"다른 월",type:"custom",silent:true,z:1,data:background,
    encode:{x:[0,2],y:[1,3]},renderItem:(params,api)=>{
      const a=api.coord([api.value(0),api.value(1)]), b=api.coord([api.value(2),api.value(3)]);
      return {type:"line",shape:{x1:a[0],y1:a[1],x2:b[0],y2:b[1]},style:{stroke:ink3,opacity:Math.min(.09,3/ms.length),lineWidth:1}};
    }});
  const routeColors=plotted.map((_,i)=>css("--s"+(i%8+1)));
  const routeData=(route,get)=>route.stations.map(st=>{
    const value=get(records[st.name]);
    return {value:[indices.get(st.name),shown(value)?value:null],
      symbolSize:shown(value)?concSize(cpt(value),6,15):0,itemStyle:{color:shown(value)?concColor(cpt(value)):panel}};
  });
  plotted.forEach((route,i)=>{
    const label=combined?route.name+" · ":"", color=combined?routeColors[i]:css("--accent");
    if(focus>=0) ser.push({name:label+mLong(ms[focus]),type:"line",z:5,data:routeData(route,r=>r.values[focus]),
      connectNulls:false,lineStyle:{width:2.6,color},itemStyle:{color}});
    ser.push({name:label+"기간 평균",type:"line",z:6,data:routeData(route,r=>r.stats.mean),
      connectNulls:false,symbol:"rect",lineStyle:{width:2,type:"dashed",color:combined?color:css("--ink")},itemStyle:{color}});
  });
  const highlights=stations.flatMap(st=>{
    const {values,stats}=records[st.name], max=values.indexOf(stats.max), min=values.indexOf(stats.min);
    return values.flatMap((v,i)=>{
      if(!shown(v)) return [];
      const flags=[i===max?"최대":null,i===min?"최소":null,qcAt(st.name,ms[i],S.item).some(q=>q.type==="outlier")?"이상값 의심":null].filter(Boolean);
      return flags.length ? [{value:[indices.get(st.name),v],month:ms[i],flags,itemStyle:{
        color:css(flags.includes("이상값 의심")?"--qc-out":flags.includes("최대")?"--above":"--below")}}] : [];
    });
  });
  ser.push({name:"최대·최소·이상값 의심",type:"scatter",z:8,symbol:"diamond",symbolSize:9,data:highlights});
  if(S.opt.limits){
    const t=targetOf(S.item), max=values.reduce((max,v)=>Math.max(max,v),0);
    const unique=new Map((D.limits[S.item]||[]).filter(l=>shown(l.max)&&l.max<=max*1.15).map(l=>[l.max,l.code]));
    const lines=[...unique].map(([v,code])=>({yAxis:v,label:{formatter:`${code} ≤${v}`}}));
    if(shown(t)) lines.push({yAxis:t,lineStyle:{color:css("--accent"),type:"solid"},label:{formatter:`목표 ${t}`}});
    if(lines.length) ser.push({name:"__limits",type:"line",data:[],silent:true,markLine:{silent:true,symbol:"none",
      lineStyle:{color:ink3,type:"dotted"},label:{position:"insideStartTop",color:ink3,fontSize:10},data:lines}});
  }
  const title=`${S.profRiver} ${it.name} ${combined?"합류 농도 비교":"상류 → 하류"}`;
  $("pfTitle").textContent=title;
  $("pfSub").textContent=combined ? `${plotted.length}개 흐름 · 공유 지점에서 같은 값으로 만남 · 단위 ${it.unit} · 가로 간격은 배치용` :
    `${chain.length}개 지점 · ${profCustom(S.profRiver)?path.join(" → "):"지점코드 순서"} · 단위 ${it.unit}`;
  chartOn("pfChart").setOption({animation:false,textStyle:{fontFamily:css("--f-ui")},
    grid:{left:55,right:26,top:35,bottom:cats.length>7?65:43},
    tooltip:{trigger:"item",confine:true,backgroundColor:panel,borderColor:css("--line"),textStyle:{color:css("--ink"),fontSize:12},
      formatter:p=>`${esc(cats[p.value[0]])} · ${p.data.flags ? mLong(p.data.month)+" · "+p.data.flags.join("·") : esc(p.seriesName)}<br>${fmt(p.value[1],it.dec)} ${it.unit}`},
    xAxis:{type:"category",data:cats,axisLabel:{color:ink2,rotate:cats.length>7?25:0,interval:0},axisTick:{show:false}},
    yAxis:{type:log?"log":"value",name:it.unit,splitLine:{lineStyle:{color:css("--line-2")}},axisLabel:{color:ink2}},
    series:ser},true);
  const means=chain.map(s=>stats(series(s.name,S.item)).mean);
  const marks=chain.map(s=>{
    const v=series(s.name,S.item), stat=stats(v);
    return {max:v.indexOf(stat.max),min:v.indexOf(stat.min)};
  });
  const lg = $("pfLegend");
  lg.innerHTML = `${routes.length>1?'<label><input id="pfCompare" type="checkbox" '+(combined?"checked":"")+'> 합류하는 흐름 함께 보기</label>':""}
    ${combined?plotted.map((r,i)=>`<span><i class="key" style="background:${routeColors[i]};height:3px"></i>${esc(r.name)}</span>`).join(""):""}
    <label>강조 월 <select id="pfMonth"><option value="">최근 관측월</option>${ms.map(m=>`<option value="${m}" ${m===S.profMonth?"selected":""}>${mLong(m)}</option>`).join("")}</select></label>
    <label><input type="checkbox" id="pfBg" ${S.profBackground!==false?"checked":""}> 나머지 월 흐리게 표시</label>
    <span>■ 기간 평균 · ◆ 최대(빨강) · 최소(파랑) · 이상값 의심(자주)</span>`;
  if($("pfCompare")) $("pfCompare").onchange=e=>{ S.profCompare=e.target.checked; refresh(); };
  $("pfMonth").onchange = e=>{ S.profMonth=e.target.value; refresh(); };
  $("pfBg").onchange = e=>{ S.profBackground=e.target.checked; refresh(); };
  // 구간별 변화 표
  let h = `<thead><tr><th class="l stc">지점</th><th class="l">위치</th><th>기간 평균</th><th>상류 대비</th><th>변화율</th>${ms.map(m=>`<th>${mLabel(m)}</th>`).join("")}</tr></thead><tbody>`;
  const tsv = [["지점","기간 평균","상류 대비","변화율(%)",...ms]];
  chain.forEach((s,i)=>{
    const sv = series(s.name,S.item), st = stats(sv), prev = i>0?means[i-1]:null, d = (st.n && prev!=null)? st.mean-prev : null, r = d!=null && prev? d/prev*100 : null;
    const big = r!=null && r>=30, extra = (s.addr.match(/\(([^)]*)\)/)||[])[1]||"";
    h += `<tr class="${S.hl.has(s.name)?"hl":""}"><td class="l stc" data-st="${esc(s.name)}">${esc(s.name)}</td><td class="l" style="color:var(--ink-3)">${esc(extra)}</td><td class="num stat"><b>${fmt(st.mean,it.dec)}</b></td>
      <td class="num ${d>0?"up":d<0?"dn":""}">${d==null?"":(d>0?"+":"")+fmt(d,it.dec)}</td><td class="num ${big?"up":""}">${r==null?"":(Math.round(r)>0?"+":"")+(Math.round(r)||0)+"%"}${big?' <span class="g">▲</span>':""}</td>
      ${sv.map((v,k)=>{ const important=k===marks[i].max || k===marks[i].min || qcAt(s.name,ms[k],S.item).some(q=>q.type==="outlier"); return cellHtml(s.name,ms[k],S.item,v,st,it.dec).replace('<td class="num','<td class="num '+(important?"pf-key":"pf-muted")); }).join("")}</tr>`;
    tsv.push([s.name, st.mean!=null?+st.mean.toFixed(4):"", d!=null?+d.toFixed(4):"", r!=null?+r.toFixed(1):"", ...sv.map(v=>v??"")]);
  });
  const tb = $("pfTbl"); tb.innerHTML = h + "</tbody>";
  tb.querySelectorAll("td[data-st]").forEach(x=>x.onclick=()=>toggleHl(x.dataset.st));
  cache.pfTsv = tsv;
}

// 비교할 흐름은 공유 지점이 있는 실제 경로다. 하류 구간만 반복하는 그룹은 제외한다.
function profileRoutes(groups,chain){
  const by=stationCodes();
  const candidates=groups.map(g=>({name:g.name,codes:branchPath(groups,g.name).filter(code=>by[code])}));
  const routes=candidates.filter((route,i)=>route.codes.length>1 && !candidates.some((other,j)=>
    i!==j && (other.codes.length>route.codes.length || (other.codes.length===route.codes.length && j<i)) &&
    route.codes.every((code,k)=>code===other.codes[other.codes.length-route.codes.length+k])));
  const active=new Set(chain.map(stationCode));
  return routes.filter(route=>route.codes.some(code=>active.has(code)) && routes.some(other=>other!==route &&
    route.codes.some((code,i)=>i>0 && other.codes.includes(code) && other.codes[other.codes.indexOf(code)-1]!==route.codes[i-1])))
    .map(route=>({name:route.name,stations:route.codes.map(code=>by[code])}));
}

// 같은 지점에는 한 x좌표만 준다. 공유 지점은 모든 상류 지점보다 오른쪽에 둔다.
function profileColumns(routes){
  const depths=new Map();
  routes.forEach(route=>route.stations.forEach((station,i)=>{
    const depth=route.stations.length-1-i;
    depths.set(station,Math.max(depths.get(station)??0,depth));
  }));
  return [...depths.keys()].sort((a,b)=>depths.get(b)-depths.get(a));
}
